import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from rplidar import RPLidar, RPLidarException

# Configurer le port série pour le LiDAR
PORT_NAME = '/dev/ttyUSB0'  # Changez cela si nécessaire

# Initialisation du LiDAR
lidar = RPLidar(PORT_NAME)

# Initialisation du plot Matplotlib
fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
line, = ax.plot([], [], 'bo', ms=2)

# Fonction de mise à jour pour le plot
def update(data):
    angles, distances = data
    line.set_data(angles, distances)
    return line,

# Fonction pour traiter les données brutes du LiDAR
def process_data(scan):
    angles = []
    distances = []
    for (_, angle, distance) in scan:
        if distance > 0:  # Filtrer les distances invalides
            angles.append(np.radians(angle))
            distances.append(distance)
    return angles, distances

# Générateur de données
def data_gen():
    try:
        for scan in lidar.iter_scans():
            yield process_data(scan)
    except RPLidarException as e:
        print(f'Erreur: {e}')
        lidar.stop()
        lidar.disconnect()

# Configuration de l'animation
ani = FuncAnimation(fig, update, data_gen, blit=True)

# Configuration de l'affichage du graphe
ax.set_ylim(0, 4000)  # Distance maximale (en millimètres) que le LiDAR peut détecter
ax.set_theta_zero_location('N')
ax.set_theta_direction(-1)

# Afficher le graphe
plt.show()

# Arrêter le LiDAR proprement à la fin
lidar.stop()
lidar.disconnect()
